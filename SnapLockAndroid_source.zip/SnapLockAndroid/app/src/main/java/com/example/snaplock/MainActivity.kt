package com.example.snaplock

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("snaplock", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(18, 18, 24))
        }
        val title = TextView(this).apply {
            text = "SnapLock"
            textSize = 30f
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Verrouillage de Snapchat par biométrie"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 24)
        }
        val toggle = Switch(this).apply {
            text = "Activer le verrouillage"
            textSize = 18f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
            }
        }
        val accessibility = Button(this).apply {
            text = "Autoriser la détection d'applications"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val info = TextView(this).apply {
            text = "Pour fonctionner, active le service SnapLock dans Accessibilité. Android affichera un avertissement système : vérifie les autorisations avant de l'activer. Le bouton ON/OFF contrôle la protection."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(toggle)
        layout.addView(accessibility, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 20 })
        layout.addView(info)
        setContentView(layout)
    }
}
